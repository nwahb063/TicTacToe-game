public interface Player {

	void play(TicTacToeGame game);
	 
}